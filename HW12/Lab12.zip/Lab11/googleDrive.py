from Google import Create_Service
from googleapiclient.http import MediaFileUpload
import os
import sys

CLIENT_SECRET_FILE = r'C:\Users\drao\Desktop\googleDrivePythonProject\Client_Secret_Google_Cloud.json'
API_NAME = 'drive'
API_VERSION = 'v3'
SCOPES = ['https://www.googleapis.com/auth/drive']
folderID = None
directoryLocation = None
listDir = None
listExtensions = None
googleDriveService = None


def gService():
    gService = Create_Service(
        CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)
    return gService

#responsible for creating folder and gservice
def gDriveCreateFolder():
    # Make a folder Named EhicalHacker
    folderName = 'EthicalHacker'
    folderMimeType = 'application/vnd.google-apps.folder'

    folder_Meta_Data = {
        'name': folderName,
        'mimeType': folderMimeType
        # No need to add folder parent as we are going to be creating that outside
        # 'parents': []
    }
    global googleDriveService
    googleDriveService = gService()
    folder = googleDriveService.files().create(body=folder_Meta_Data).execute()
    global folderID
    folderID = folder.get('id')
    print("Folder ID: " + folderID)


def inputProcessor():

    global directoryLocation
    print("Please provide the location of the Folder")
    directoryLocation = input()
    print(
        'Please provide the extension(s) you want to target for upload Process. (Note:seperate each extension followed by comma [,]. DO NOT OMIT DOT WHEN PROVIDING THE EXTENSIONS )')
    strExtensions = input()
    
    # for testing:
    # directoryLocation = r"C:\Users\drao\Desktop\googleDrivePythonProject\pythonTest"
    # Change Location to the directory
    os.chdir(directoryLocation)
    # Lists the files in the directory and stores the information in a List => variable listDir
    global listDir
    listDir = os.listdir(directoryLocation)
    # for testing:
    # strExtensions = '.txt,.bmp,.docx,.jpg'
    # Splits on the comma and stores in the list.
    global listExtensions
    listExtensions = strExtensions.split(",")
    if checkIfDuplicates(listExtensions) == False:
        for ext in listExtensions:
            if(extentionExist(ext, listDir)):
                pass
            else:
                print("Error: " + ext + " extension was not found in the Folder.")
                sys.exit()
        gDriveCreateFolder()
        RunBasedOnCond()
        print("Done Successfully!")
    else:
        print("Error: Duplicate input for one or more extensions is not allowed. Extensions must be Unique")

def checkIfDuplicates(listOfElems):
    ''' Check if given list contains any duplicates '''    
    for elem in listOfElems:
        if listOfElems.count(elem) > 1:
            return True
    return False

def RunBasedOnCond():
    global listExtensions
    fileList = listDir

    print("Extension(s) Selected:")
    print(listExtensions)

    #iterate over input extensions
    for ext in listExtensions:
        print("Currently processing " + ext + " files...")
        if ext == '.aac':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.aac'):
                    fileProcessor(fileName, 'audio/aac')
        elif ext == '.abw':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.abw'):
                    fileProcessor(fileName, 'application/x-abiword')
        elif ext == '.arc':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.arc'):
                    fileProcessor(fileName, 'application/x-freearc')
        elif ext == '.avi':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.avi'):
                    fileProcessor(fileName, 'video/x-msvideo')
        elif ext == '.azw':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.azw'):
                    fileProcessor(fileName, 'application/vnd.amazon.ebook')
        elif ext == '.bin':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.bin'):
                    fileProcessor(fileName, 'application/octet-stream')
        elif ext == '.bmp':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.bmp'):
                    fileProcessor(fileName, 'image/bmp')
        elif ext == '.bz':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.bz'):
                    fileProcessor(fileName, 'application/x-bzip')
        elif ext == '.bz2':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.bz2'):
                    fileProcessor(fileName, 'application/x-bzip2')
        elif ext == '.csh':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.csh'):
                    fileProcessor(fileName, 'application/x-csh')
        elif ext == '.css':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.css'):
                    fileProcessor(fileName, 'text/csv')
        elif ext == '.csv':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.csv'):
                    fileProcessor(fileName, 'text/csv')
        elif ext == '.doc':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.doc'):
                    fileProcessor(fileName, 'application/msword')
        elif ext == '.docx':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.docx'):
                    fileProcessor(fileName, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
        elif ext == '.eot':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.eot'):
                    fileProcessor(fileName, 'application/vnd.ms-fontobject')
        elif ext == '.epub':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.epub'):
                    fileProcessor(fileName, 'application/epub+zip')
        elif ext == '.gz':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.gz'):
                    fileProcessor(fileName, 'application/gzip')
        elif ext == '.gif':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.gif'):
                    fileProcessor(fileName, 'image/gif')
        elif ext == '.htm':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.htm'):
                    fileProcessor(fileName, 'text/html')
        elif ext == '.html':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.html'):
                    fileProcessor(fileName, 'text/html')
        elif ext == '.ico':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ico'):
                    fileProcessor(fileName, 'image/vnd.microsoft.icon')
        elif ext == '.ics':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ics'):
                    fileProcessor(fileName, 'text/calendar')
        elif ext == '.jar':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.jar'):
                    fileProcessor(fileName, 'application/java-archive')
        elif ext == '.jpeg':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.jpeg'):
                    fileProcessor(fileName, 'image/jpeg')
        elif ext == '.jpg':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.jpg'):
                    fileProcessor(fileName, 'image/jpeg')
        elif ext == '.js':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.js'):
                    fileProcessor(fileName, 'text/javascript')
        elif ext == '.json':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.json'):
                    fileProcessor(fileName, 'application/json')
        elif ext == '.jsonld':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.jsonld'):
                    fileProcessor(fileName, 'application/ld+json')
        elif ext == '.mid':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.mid'):
                    fileProcessor(fileName, 'audio/midi audio/x-midi')
        elif ext == '.midi':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.midi'):
                    fileProcessor(fileName, 'audio/midi audio/x-midi')
        elif ext == '.mjs':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.mjs'):
                    fileProcessor(fileName, 'text/javascript')
        elif ext == '.mp3':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.mp3'):
                    fileProcessor(fileName, 'audio/mpeg')
        elif ext == '.cda':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.cda'):
                    fileProcessor(fileName, 'application/x-cdf')
        elif ext == '.mp4':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.mp4'):
                    fileProcessor(fileName, 'video/mp4')
        elif ext == '.mpeg':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.mpeg'):
                    fileProcessor(fileName, 'video/mpeg')
        elif ext == '.mpkg':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.mpkg'):
                    fileProcessor(fileName, 'application/vnd.apple.installer+xml')
        elif ext == '.odp':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.odp'):
                    fileProcessor(fileName, 'application/vnd.oasis.opendocument.presentation')
        elif ext == '.ods':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ods'):
                    fileProcessor(fileName, 'application/vnd.oasis.opendocument.spreadsheet')
        elif ext == '.odt':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.odt'):
                    fileProcessor(fileName, 'application/vnd.oasis.opendocument.text')
        elif ext == '.oda':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.oda'):
                    fileProcessor(fileName, 'audio/ogg')
        elif ext == '.odv':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.odv'):
                    fileProcessor(fileName, 'video/ogg')
        elif ext == '.ogx':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ogx'):
                    fileProcessor(fileName, 'application/ogg')
        elif ext == '.opus':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.opus'):
                    fileProcessor(fileName, 'audio/opus')
        elif ext == '.otf':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.otf'):
                    fileProcessor(fileName, 'font/otf')
        elif ext == '.png':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.png'):
                    fileProcessor(fileName, 'image/png')
        elif ext == '.pdf':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.pdf'):
                    fileProcessor(fileName, 'application/pdf')
        elif ext == '.php':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.php'):
                    fileProcessor(fileName, 'application/x-httpd-php')
        elif ext == '.ppt':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ppt'):
                    fileProcessor(fileName, 'application/vnd.ms-powerpoint')
        elif ext == '.pptx':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.pptx'):
                    fileProcessor(fileName, 'application/vnd.openxmlformats-officedocument.presentationml.presentation')
        elif ext == '.rar':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.rar'):
                    fileProcessor(fileName, 'application/vnd.rar')
        elif ext == '.rtf':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.rtf'):
                    fileProcessor(fileName, 'application/rtf')
        elif ext == '.sh':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.sh'):
                    fileProcessor(fileName, 'application/x-sh')
        elif ext == '.svg':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.svg'):
                    fileProcessor(fileName, 'image/svg+xml')
        elif ext == '.swf':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.swf'):
                    fileProcessor(fileName, 'application/x-shockwave-flash')
        elif ext == '.tar':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.tar'):
                    fileProcessor(fileName, 'application/x-tar')
        elif ext == '.txt':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.txt'):
                    fileProcessor(fileName, 'text/plain')
        elif ext == '.tif':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.tif'):
                    fileProcessor(fileName, 'image/tiff')
        elif ext == '.tiff':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.tiff'):
                    fileProcessor(fileName, 'image/tiff')
        elif ext == '.ts':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ts'):
                    fileProcessor(fileName, 'video/mp2t')
        elif ext == '.ttf':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.ttf'):
                    fileProcessor(fileName, 'font/ttf')
        elif ext == '.vsd':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.vsd'):
                    fileProcessor(fileName, 'application/vnd.visio')
        elif ext == '.wav':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.wav'):
                    fileProcessor(fileName, 'audio/wav')
        elif ext == '.weba':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.weba'):
                    fileProcessor(fileName, 'audio/webm')
        elif ext == '.webm':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.webm'):
                    fileProcessor(fileName, 'video/webm')
        elif ext == '.webp':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.webp'):
                    fileProcessor(fileName, 'image/webp')

        elif ext == '.woff':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.woff'):
                    fileProcessor(fileName, 'font/woff')
        elif ext == '.woff2':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.woff2'):
                    fileProcessor(fileName, 'font/woff2')
        elif ext == '.xhtml':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.xhtml'):
                    fileProcessor(fileName, 'application/xhtml+xml')
        elif ext == '.xls':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.xls'):
                    fileProcessor(fileName, 'application/vnd.ms-excel')
        elif ext == '.xlsx':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.xlsx'):
                    fileProcessor(fileName, 'officedocument.spreadsheetml.sheet')
        elif ext == '.xml':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.xml'):
                    fileProcessor(fileName, 'application/xml')
        elif ext == '.xul':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.xul'):
                    fileProcessor(fileName, 'application/vnd.mozilla.xul+xml')
        elif ext == '.zip':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.zip'):
                    fileProcessor(fileName, 'application/zip')
        elif ext == '.7z':
            #iterate over files in the folder
            for fileName in fileList:
                if fileName.endswith('.7z'):
                    fileProcessor(fileName, 'application/x-7z-compressed')
        else:
            print("Error: Extension: " + ext  + " not compatible. Please Edit this script to make the desired changes")



def extentionExist(ext, listDir):
    for fileName in listDir:
        if fileName.endswith(ext):
            return True
    return False       

def fileProcessor(fileName, mimeType):
    global folderID
    file_metadata = {
        'name': fileName,
        'mimeType': mimeType,
        'parents': [folderID]
    }

    filePath = directoryLocation + '\\' + fileName

    media = MediaFileUpload(filePath, mimetype= mimeType)

    global googleDriveService
    googleDriveService.files().create(
    body=file_metadata, media_body=media, fields='id').execute()


if __name__ == '__main__':
    inputProcessor()
